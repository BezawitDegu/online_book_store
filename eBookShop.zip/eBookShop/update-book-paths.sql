-- Update book file paths to point to the shared real PDF on disk.
-- Run these commands after ensuring ebooks/sample.pdf exists.

UPDATE books
SET file_path = 'ebooks/sample.pdf'
WHERE file_path IS NULL
	OR file_path = ''
	OR file_path = 'ebooks/books.txt'
	OR file_path = 'classpath:/books/Sample.pdf'
	OR file_path = 'classpath:/books/sample.pdf'
	OR file_path = 'src/main/resources/books/Sample.pdf'
	OR file_path = 'src/main/resources/books/sample.pdf';
