# eBookShop

A JavaFX + MySQL book store application for browsing books, managing a cart, placing orders, and administering inventory.

## Features

- User login and registration
- Browse and search books
- Shopping cart and checkout flow
- Order history and receipt generation
- Admin dashboard for inventory and customer overview
- MySQL-backed persistence

## Requirements

- JDK 17
- MySQL 8+
- VS Code with the Java extension pack, or another IDE that can run JavaFX apps

## Google Sign-In Setup

The login and registration screens now include a Google sign-in option.

To enable it, create an OAuth client in Google Cloud and set the following before launching the app:

- `GOOGLE_OAUTH_CLIENT_ID`
- `GOOGLE_OAUTH_CLIENT_SECRET` (optional for some client setups)

Your OAuth client must allow a loopback redirect such as `http://127.0.0.1`.

## Database Setup

1. Create a MySQL database named `ebookshop`.
2. Run `schema.sql` to create the tables and seed the default data.
3. If you use a different MySQL username or password, update `src/main/java/com/mycompany/ebookshop/database/DBConnection.java`.

Default seeded admin account:

- Username: `admin`
- Password: `admin123`

## Run the Application

### Option 1: VS Code

- Use the build task provided in `.vscode/compile-ebookshop.ps1`.
- Launch `com.mycompany.ebookshop.MainApp` from your IDE.

### Option 2: Maven

If Maven is installed locally, you can run:

```bash
mvn javafx:run
```

If you want a packaged JAR, run:

```bash
mvn clean package
```

## Project Structure

- `src/main/java` - application source code
- `src/main/resources` - FXML, CSS, and images
- `schema.sql` - database schema and seed data
- `pom.xml` - Maven build configuration

## Notes

- The app currently accepts both legacy plain-text passwords and hashed passwords so existing seeded accounts keep working.
- If you change the database schema or credentials, make sure `DBConnection.java` matches your local MySQL setup.
- Google sign-in verifies the Google account in the browser, then uses the email to prefill or load the local user account.

## NetBeans (IDE) — Quick setup

If you run the project from NetBeans, provide credentials using one of these approaches:

- VM Options (temporary for runs launched by NetBeans):

	Add the following to the project's Run > VM Options (replace with your values):

	-Dgoogle.oauth.clientId=YOUR_CLIENT_ID -Dgoogle.oauth.clientSecret=YOUR_CLIENT_SECRET

- Local properties file (recommended to avoid storing secrets in project metadata):

	1. Copy `oauth.properties.example` from the project root to your user config folder:

		 - Windows: `C:\Users\<you>\.ebookshop\oauth.properties`
		 - Unix: `~/.ebookshop/oauth.properties`

	2. Fill in `GOOGLE_OAUTH_CLIENT_ID` and `GOOGLE_OAUTH_CLIENT_SECRET`.

The application will read configuration in this order: JVM system properties, environment variables, then the local `~/.ebookshop/oauth.properties` file.

Do not commit real secrets into your repository.
