package com.mycompany.ebookshop.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class PasswordUtilsHarness {

    public static void main(String[] args) {
        shouldHashAndVerify();
        shouldRejectWrongPassword();
        shouldVerifyLegacySha256();
        System.out.println("PasswordUtilsHarness passed.");
    }

    private static void shouldHashAndVerify() {
        String password = "TestPass123!";
        String stored = PasswordUtils.hashPassword(password);
        require(stored != null && stored.startsWith("pbkdf2$"), "Expected PBKDF2 hash");
        require(PasswordUtils.verifyPassword(password, stored), "Expected password to verify");
    }

    private static void shouldRejectWrongPassword() {
        String password = "TestPass123!";
        String stored = PasswordUtils.hashPassword(password);
        require(!PasswordUtils.verifyPassword("wrong", stored), "Expected wrong password to fail");
    }

    private static void shouldVerifyLegacySha256() {
        String password = "legacyPass";
        String legacyHash = sha256Base64(password);
        require(PasswordUtils.verifyPassword(password, legacyHash), "Expected legacy SHA-256 hash to verify");
        require(!PasswordUtils.verifyPassword("different", legacyHash), "Expected legacy SHA-256 hash to reject wrong password");
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new IllegalStateException(message);
        }
    }

    private static String sha256Base64(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Unable to compute legacy hash", e);
        }
    }
}
