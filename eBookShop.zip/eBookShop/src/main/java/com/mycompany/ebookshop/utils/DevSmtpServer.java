package com.mycompany.ebookshop.utils;

import com.icegreen.greenmail.util.GreenMail;
import com.icegreen.greenmail.util.ServerSetup;

import java.io.InputStream;
import java.util.Properties;

/**
 * Small helper to start an embedded SMTP server for local development when the
 * configured SMTP host is localhost. This allows the app to send emails without
 * requiring an external MailHog/SMTP process.
 */
public class DevSmtpServer {
    private static GreenMail greenMail;

    public static void startIfLocalConfig() {
        try {
            Properties props = new Properties();
            // load classpath mail.properties if present
            try (InputStream in = DevSmtpServer.class.getClassLoader().getResourceAsStream("mail.properties")) {
                if (in != null) props.load(in);
            } catch (Exception ignored) {
            }

            String host = System.getProperty("mail.smtp.host", props.getProperty("mail.smtp.host", "localhost"));
            String portStr = System.getProperty("mail.smtp.port", props.getProperty("mail.smtp.port", "1025"));
            int port = Integer.parseInt(portStr);

            // Only start embedded server for local host addresses
            if (host == null) host = "localhost";
            String lower = host.toLowerCase().trim();
            if (!("localhost".equals(lower) || "127.0.0.1".equals(lower) || lower.startsWith("::1"))) {
                return;
            }

            if (greenMail != null && greenMail.isRunning()) return;

            ServerSetup setup = new ServerSetup(port, null, ServerSetup.PROTOCOL_SMTP);
            greenMail = new GreenMail(setup);
            greenMail.start();
            System.out.println("[DevSmtpServer] Started embedded SMTP on port " + port + " for development (GreenMail)");

            // Stop on JVM exit
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    if (greenMail != null) {
                        greenMail.stop();
                        System.out.println("[DevSmtpServer] Stopped embedded SMTP");
                    }
                } catch (Exception ignored) {
                }
            }));
        } catch (Exception e) {
            System.err.println("[DevSmtpServer] Could not start embedded SMTP: " + e.getMessage());
        }
    }
}
