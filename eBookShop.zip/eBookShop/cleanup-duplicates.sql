-- Remove duplicate books, keeping only the first entry of each ISBN
-- Run this in MySQL if you have duplicates in your database

DELETE b1 FROM books b1
INNER JOIN books b2 
WHERE b1.id > b2.id 
AND b1.isbn = b2.isbn 
AND b1.isbn IS NOT NULL 
AND b1.isbn != '';

-- Verify results
SELECT COUNT(*) as total_books, COUNT(DISTINCT isbn) as unique_isbns FROM books;
