-- Update placeholder or empty image_url to OpenLibrary covers using isbn
USE ebookshop;

UPDATE books
SET image_url = CONCAT('https://covers.openlibrary.org/b/isbn/', REPLACE(TRIM(isbn), '-', ''), '-L.jpg')
WHERE (image_url IS NULL OR image_url = '' OR image_url LIKE 'https://placehold.co/%' OR image_url LIKE 'https://placehold.co%')
  AND isbn IS NOT NULL AND TRIM(isbn) <> '';

-- To preview the rows that will be updated run:
-- SELECT id, title, isbn, image_url FROM books WHERE image_url IS NULL OR image_url = '' OR image_url LIKE 'https://placehold.co/%';
