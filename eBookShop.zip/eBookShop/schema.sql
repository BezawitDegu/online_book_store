-- eBookShop Database Schema

CREATE DATABASE IF NOT EXISTS ebookshop;
USE ebookshop;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100),
    address VARCHAR(255),
    phone VARCHAR(30),
    security_question VARCHAR(255),
    security_answer VARCHAR(255),
    email_verified TINYINT(1) DEFAULT 0,
    oauth_provider VARCHAR(50) DEFAULT NULL,
    oauth_subject VARCHAR(255) DEFAULT NULL,
    role VARCHAR(20) DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    author VARCHAR(100) NOT NULL,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50),
    description TEXT,
    image_url VARCHAR(255),
    file_path VARCHAR(512),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_date DATETIME NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'PENDING',
    shipping_address TEXT DEFAULT NULL,
    payment_method VARCHAR(50) DEFAULT NULL,
    receipt_path VARCHAR(512) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    book_id INT NOT NULL,
    book_title VARCHAR(150) DEFAULT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    UNIQUE KEY uq_order_items_order_book (order_id, book_id),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (book_id) REFERENCES books(id)
);

CREATE TABLE IF NOT EXISTS cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cart_user_book (user_id, book_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

-- Insert a default admin user
INSERT IGNORE INTO users (username, password, email, full_name, address, phone, security_question, security_answer, role)
VALUES ('admin', 'Admin@123', 'mikiasmulu29@gmail.com', 'Administrator', '123 Dev St', '555-0000', NULL, NULL, 'admin');

INSERT IGNORE INTO books (title, author, isbn, price, category, description, image_url)
VALUES
('Effective Java', 'Joshua Bloch', '9780134685991', 45.99, 'Technology', 'Best practices for the Java platform', 'https://covers.openlibrary.org/b/isbn/9780134685991-L.jpg'),
('Clean Code', 'Robert C. Martin', '9780132350884', 39.99, 'Technology', 'A handbook of agile software craftsmanship', 'https://covers.openlibrary.org/b/isbn/9780132350884-L.jpg'),
('The Pragmatic Programmer', 'Andrew Hunt and David Thomas', '9780201616224', 42.50, 'Technology', 'Your journey to mastery in software development', 'https://covers.openlibrary.org/b/isbn/9780201616224-L.jpg'),
('Head First Java', 'Kathy Sierra and Bert Bates', '9780596009205', 34.99, 'Technology', 'A learner-friendly introduction to Java', 'https://covers.openlibrary.org/b/isbn/9780596009205-L.jpg'),
('The Great Gatsby', 'F. Scott Fitzgerald', '9780743273565', 14.99, 'World Literature', 'Classic American novel of the Jazz Age', 'https://covers.openlibrary.org/b/isbn/9780743273565-L.jpg'),
('To Kill a Mockingbird', 'Harper Lee', '9780061120084', 16.50, 'World Literature', 'A timeless story of justice and empathy', 'https://covers.openlibrary.org/b/isbn/9780061120084-L.jpg');
