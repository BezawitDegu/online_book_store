-- Remove duplicate rows for the same book within the same order (keep earliest id)
DELETE oi1
FROM order_items oi1
JOIN order_items oi2
  ON oi1.order_id = oi2.order_id
 AND oi1.book_id = oi2.book_id
 AND oi1.id > oi2.id;

-- Enforce one row per (order, book)
ALTER TABLE order_items
  ADD CONSTRAINT uq_order_items_order_book UNIQUE (order_id, book_id);
