-- Create test user for login demo
-- Username: miki
-- Password: miki123 (will be hashed by app)

USE ebookshop;

-- Insert test user (password stored as plain text for testing)
INSERT IGNORE INTO users (username, password, email, full_name, address, phone, role)
VALUES ('miki', 'miki123', 'miki@test.com', 'Miki User', '456 Test Ave', '555-1234', 'customer');

SELECT 'Test user created' as Status;
SELECT username, email, role FROM users WHERE username = 'miki';
